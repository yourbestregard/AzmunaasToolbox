#!/system/bin/sh
#
# Android Identity Changer
# Profile: Infinix X655F (Infinix-X655F)
#
# Skrip ini akan dijalankan dengan hak akses root.
# Menggunakan 'resetprop' untuk mengubah properti sistem secara systemless.

# --- Properti Utama ---
resetprop ro.product.brand Infinix
resetprop ro.product.manufacturer Infinix
resetprop ro.product.model Infinix-X655F
resetprop ro.product.device Infinix-X655F
resetprop ro.product.name X655F-IN
resetprop ro.build.product X655F-IN

# --- Fingerprint dan Deskripsi Build ---
# Ini adalah properti paling penting untuk spoofing
FINGERPRINT="Infinix/X655F-IN/Infinix-X655F:10/QP1A.190711.020/E-200102V108:user/release-keys"
DESCRIPTION="X655F-IN-user 10 QP1A.190711.020 E-200102V108 release-keys"
resetprop ro.build.fingerprint "$FINGERPRINT"
resetprop ro.bootimage.build.fingerprint "$FINGERPRINT"
resetprop ro.system.build.fingerprint "$FINGERPRINT"
resetprop ro.vendor.build.fingerprint "$FINGERPRINT"
resetprop ro.odm.build.fingerprint "$FINGERPRINT"
resetprop ro.product.build.fingerprint "$FINGERPRINT"
resetprop ro.system_ext.build.fingerprint "$FINGERPRINT"

resetprop ro.build.description "$DESCRIPTION"

# --- Properti Build Lainnya ---
resetprop ro.build.id QP1A.190711.020
resetprop ro.build.version.incremental E-200102V108
resetprop ro.build.version.release 10 
resetprop ro.build.date "2020-01-02 12:00:00"
resetprop ro.build.date.utc $(date -d "2020-01-02 12:00:00" +%s)
resetprop ro.build.tags release-keys
resetprop ro.build.type user

# --- Tambahan: Security Patch (sesuai permintaan) ---
# Format YYYY-MM-DD. Gunakan tanggal yang sesuai dengan fingerprint.
SECURITY_PATCH="2020-01-05"
resetprop ro.build.version.security_patch "$SECURITY_PATCH"
resetprop ro.vendor.build.security_patch "$SECURITY_PATCH"

# --- Membersihkan properti debugging/custom ROM (opsional tapi bagus) ---
resetprop ro.build.user "builder"
resetprop ro.debuggable 0
resetprop ro.build.host "build-host"

# Memberi tahu UI bahwa skrip telah selesai
echo "Identitas berhasil diubah ke Infinix X655F."
echo "Silakan reboot perangkat Anda agar semua perubahan diterapkan."